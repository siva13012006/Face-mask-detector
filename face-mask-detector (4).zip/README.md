# Face Mask Detector

Detects if a person is wearing a mask using webcam.